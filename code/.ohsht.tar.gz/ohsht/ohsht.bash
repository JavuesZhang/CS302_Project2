if [[ -d ~/.ohsht/ ]]; then
    export PATH=~/.ohsht/bin:"${PATH}"
fi

export OS_SHELL_ALIASES=$(alias);

sht() {
    cmd=$(fc -ln -1)
    out=$(ohsht ${@} "$cmd")
    echo -e "\033[32mDon't worry! Calm down plz. I'll try to fix it for u~\033[0m"
    echo -e "\033[42;37m[Corrected command] $out \033[0m"
    if [[ $out == '' ]]; then
        echo "Sorry, there seems no fix..."
    else
        perl -e 'require "sys/ioctl.ph"; ioctl(STDIN, &TIOCSTI, $_) for split "", join " ", @ARGV' $out
	echo -ne "\r"
    fi
}

