if [[ -d ~/.myautojump/ ]]; then
    export PATH=~/.myautojump/bin:"${PATH}"
fi

export AJ_DATA_PATH=~/.myautojump/bin/data.txt
if [ ! -f "$AJ_DATA_PATH" ]; then
	touch "$AJ_DATA_PATH"
fi

aj_add_to_data(){
	myautojump --add "$(pwd)"
}

export PROMPT_COMMAND="${PROMPT_COMMAND} ; aj_add_to_data"

aj() {
	if [[ ${1} == -* ]]; then
		myautojump ${@}
		return
	fi

	output="$(myautojump ${@})"
	cd "${output}"
}

ajc() {
	if [[ ${1} == -* ]]; then
		myautojump ${@}
		return
	fi

	aj $(pwd) ${@}
}

ajo() {
	if [[ ${1} == -* ]]; then
		myautojump ${@}
		return
	fi

	output="$(myautojump ${@})"
	nautilus "${output}"
}

ajoc() {
	if [[ ${1} == -* ]]; then
		myautojump ${@}
		return
	fi

	ajo $(pwd) ${@}
}
