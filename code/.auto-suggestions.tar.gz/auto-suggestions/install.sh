#!/bin/bash 

DIR=$(pwd)
cat >> ~/.inputrc <<'EOF'
"\e[A": history-search-backward
"\e[B": history-search-forward
EOF
  

echo "bind -f ~/.inputrc" >> ~/.bashrc
echo "source "${DIR}"/as-completion" >> ~/.bashrc
echo "source "${DIR}"/ad" >> ~/.bashrc






